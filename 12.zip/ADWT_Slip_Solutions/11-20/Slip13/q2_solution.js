// Create database
use student_db

// Create collections
db.createCollection("students")
db.createCollection("competitions")
db.createCollection("participations")

// Insert students
db.students.insertMany([
  { "_id": 1, "name": "Alice Smith", "class": "FY" },
  { "_id": 2, "name": "Bob Johnson", "class": "FY" },
  { "_id": 3, "name": "Charlie Brown", "class": "SY" },
  { "_id": 4, "name": "David Lee", "class": "SY" },
  { "_id": 5, "name": "Eve Davis", "class": "TY" },
  { "_id": 6, "name": "Frank White", "class": "TY" },
  { "_id": 7, "name": "Grace Hall", "class": "FY" },
  { "_id": 8, "name": "Heidi King", "class": "SY" },
  { "_id": 9, "name": "Ivan Scott", "class": "TY" },
  { "_id": 10, "name": "Judy Adams", "class": "FY" }
])

// Insert competitions
db.competitions.insertMany([
  { "_id": 1, "name": "Programming", "type": "Technical" },
  { "_id": 2, "name": "E-Rangoli", "type": "Cultural" },
  { "_id": 3, "name": "Debate", "type": "Literary" },
  { "_id": 4, "name": "Robo-Wars", "type": "Technical" },
  { "_id": 5, "name": "Chess", "type": "Strategy" }
])

// Insert participations
db.participations.insertMany([
  // Programming (1) participants
  { "student_id": 3, "competition_id": 1, "rank": 1 },
  { "student_id": 5, "competition_id": 1, "rank": 2 },
  { "student_id": 9, "competition_id": 1, "rank": 3 },
  { "student_id": 1, "competition_id": 1, "rank": 10 },
  { "student_id": 4, "competition_id": 1, "rank": 11 },
  // E-Rangoli (2) participants
  { "student_id": 2, "competition_id": 2, "rank": 1 },
  { "student_id": 7, "competition_id": 2, "rank": 2 },
  { "student_id": 1, "competition_id": 2, "rank": 3 },
  { "student_id": 10, "competition_id": 2, "rank": 4 },
  { "student_id": 8, "competition_id": 2, "rank": 5 },
  // Debate (3) participants
  { "student_id": 6, "competition_id": 3, "rank": 1 },
  { "student_id": 8, "competition_id": 3, "rank": 2 },
  { "student_id": 3, "competition_id": 3, "rank": 3 },
  // Robo-Wars (4) participants
  { "student_id": 4, "competition_id": 4, "rank": 1 },
  { "student_id": 9, "competition_id": 4, "rank": 2 },
  { "student_id": 5, "competition_id": 4, "rank": 3 },
  { "student_id": 1, "competition_id": 4, "rank": null },
  // Chess (5) participants
  { "student_id": 7, "competition_id": 5, "rank": 1 },
  { "student_id": 2, "competition_id": 5, "rank": 2 },
  { "student_id": 10, "competition_id": 5, "rank": 3 }
])

// Query a: Display count of students participating in each competition.
db.participations.aggregate([
  {
    $group: {
      _id: "$competition_id",
      student_count: { $sum: 1 }
    }
  },
  {
    $lookup: {
      from: "competitions",
      localField: "_id",
      foreignField: "_id",
      as: "competition_details"
    }
  },
  { $unwind: "$competition_details" },
  {
    $project: {
      _id: 0,
      competition_name: "$competition_details.name",
      number_of_students: "$student_count"
    }
  },
  { $sort: { number_of_students: -1 } }
])

// Query b: Find the number of students in the 'Programming' competition.
db.competitions.aggregate([
  { $match: { name: "Programming" } },
  {
    $lookup: {
      from: "participations",
      localField: "_id",
      foreignField: "competition_id",
      as: "participants"
    }
  },
  {
    $project: {
      _id: 0,
      competition_name: "$name",
      number_of_students: { $size: "$participants" }
    }
  }
])

// Query c: Display the names of first three winners of each competition.
db.participations.aggregate([
  { $match: { rank: { $in: [1, 2, 3] } } },
  { $sort: { rank: 1 } },
  {
    $lookup: {
      from: "students",
      localField: "student_id",
      foreignField: "_id",
      as: "student_info"
    }
  },
  {
    $lookup: {
      from: "competitions",
      localField: "competition_id",
      foreignField: "_id",
      as: "comp_info"
    }
  },
  { $unwind: "$student_info" },
  { $unwind: "$comp_info" },
  {
    $group: {
      _id: "$comp_info.name",
      winners: {
        $push: {
          rank: "$rank",
          name: "$student_info.name"
        }
      }
    }
  },
  {
    $project: {
      _id: 0,
      competition_name: "$_id",
      winners: "$winners"
    }
  }
])

// Query d: Display students from class 'FY' who participated in 'E-Rangoli'.
db.students.aggregate([
  { $match: { class: "FY" } },
  {
    $lookup: {
      from: "participations",
      localField: "_id",
      foreignField: "student_id",
      as: "participations"
    }
  },
  { $unwind: "$participations" },
  {
    $lookup: {
      from: "competitions",
      localField: "participations.competition_id",
      foreignField: "_id",
      as: "competition"
    }
  },
  { $unwind: "$competition" },
  { $match: { "competition.name": "E-Rangoli" } },
  {
    $project: {
      _id: 0,
      student_name: "$name",
      class: "$class",
      competition: "$competition.name",
      rank: "$participations.rank"
    }
  }
])